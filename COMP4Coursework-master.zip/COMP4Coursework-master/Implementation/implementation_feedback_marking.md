#Technical Solution
####COMP4 Coursework Feedback and Marking
There are **20 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Processing Objectives

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Program Listing

###From System Maintenance Marking Section (Code listing/Structure)

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Samples of annotated ‘design views’ (showing details of application-generated forms, reports, queries, buttons, cross-tabulations)

###From System Maintenance Marking - System Evidence Section

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Any Other Reported Evidence

###From Testing Marking Sections - Outline Plan/Detailed Plan/Test Data

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###From Testing Marking Section Evaluation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##System Maintenance

###From System Maintenance Marking

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##User Manual

###From User Manual Marking

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |