#User Manual
####COMP4 Coursework Feedback and Marking
There are **10 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Quality of Communication

|**Strengths**||
|-|-|
||Text has been word processed|
||There are few if any errors of spelling, punctuation and grammar. If there are the meaning is still clear|
||The form and style of writing is appropriate and ideas are expressed clearly and fluently|
||Sentences and paragraphs follow on from one another clearly and coherently|
||Appropriate specialist vocabulary has been used|
|**Weaknesses**||
|| |

##Introduction

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Installation Instructions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Tutorial

###Application Walk-through

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Error Messages

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Saving

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Limitations

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Back-up

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |