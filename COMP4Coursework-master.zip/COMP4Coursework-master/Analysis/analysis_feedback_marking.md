#Analysis
####COMP4 Coursework Feedback and Marking
There are **12 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Layout

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Introduction

###Client Identification

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Definition of Current System

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Investigation (The Current System)

###Data sources and destinations

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Algorithms

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###DFDs (where relevant)

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Input Forms, Output Forms, Report Formats

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Investigation (The Proposed System)

###Data sources and destinations

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###DFDs (where relevant)

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Data Dictionary

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Volumetrics

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Objectives

###General Objectives

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Specific Objectives

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Core Objectives

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Other Objectives

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##ER Diagrams and Descriptions

###ER Diagram

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Entity Descriptions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Object Analysis

###Object Listing

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||

###Relationship Diagrams

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Class Definitions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Graphs (and Other Abstractions)

###Graphs

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Constraints

###Hardware

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Software

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Time

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###User Knowledge

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Access Restrictions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Limitations

###Areas which will not be included in computerisation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Areas considered for future computerisation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Solutions

###Alternative Solutions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Justification of Chosen Solution

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |
|| |
