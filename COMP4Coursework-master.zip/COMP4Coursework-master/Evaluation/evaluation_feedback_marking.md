#Evaluation
####COMP4 Coursework Feedback and Marking
There are **6 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Objective Evaluation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Effectiveness

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Learnability

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Usability

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Maintainability

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Improvements

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |