#Design
####COMP4 Coursework Feedback and Marking
There are **12 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Layout

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Overall System Design

###Short description of the main parts of the system

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###System flowcharts showing an overview of the complete system

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##User Interface Designs

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Hardware Specification

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Program Structure

###Top-down desing structure charts

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Algorithms in pseudo-code for each data transformation process

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Object Diagrams

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Class definitions

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Prototyping

###Consideration of impact on design and development

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Definition of Data Requirements

###Identification of all data input items

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Identification of all data output items

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Explanation of how data output items are generated

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Data Dictionary

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Identification of appropriate storage media

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Database Design

###ER Diagram

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Entity Descriptions and UNF to 3NF

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###SQL Queries

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Security and Integrity of the System and Data

###Security and Integrity of Data

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||

###System Security

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Validation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Testing

###Outline Plan

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Detailed Plan

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |