#System Maintenance
####COMP4 Coursework Feedback and Marking
There are **7 marks** available for this section.

|Name|Candidate No.|Centre No.|Draft Mark|Final Mark|
|-|-|-|:-:|:-:|
| | |22151|**0**|**0**|

##Overall Comments

##Layout

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Environment

###Software

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Usage Explanation

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Features Used

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##System Overview

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Code Structure

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Variable Listing

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##System Evidence

###User Interface

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###ER Diagram

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Database Table Views

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Database SQL

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###SQL Queries

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Testing

###Summary of Results

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Known Issues

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Code Explanations

###Difficult Sections

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

###Self-created Algorithms

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Settings

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Acknowledgements

|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |

##Code Listing
|**Strengths**||
|-|-|
|| |
|**Weaknesses**||
|| |